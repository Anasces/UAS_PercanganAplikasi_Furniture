class Furnitures{
  String name, material, description, review, price, photo;
  List<String> imgurl;

  Furnitures ({
    this.name,
    this.material,
    this.description,
    this.review,
    this.price,
    this.photo,
    this.imgurl,
  });
}